<!-- You DON'T have to delete the comments (<!- Text ->), they won't be shown in the final issue -->

### Brief description
<!-- Why its it an issue? -->

### Steps to reproduce
<!-- How can anyone reproduce the issue? -->
1. ...
2. ...
3. ...

### Expected result
<!-- What do you want to happen? -->

### Actual result
<!-- What actually happens: -->

### Server Information
* CommandShop Version: <!-- Commit number or the  link to where you got your .phar -->
* Software Version: <!-- e.g. PMMP Jenkins build #123 -->
* Server OS: <!-- e.g. Debian 8 -->

### CrashDumps/Errors
```
Paste your CrashDump or error by replacing this text (DON'T delete the backticks!)
```
