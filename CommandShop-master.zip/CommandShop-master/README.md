# CommandShop

[![Poggit-CI](https://poggit.pmmp.io/ci.shield/BoxOfDevs/CommandShop/CommandShop)](https://poggit.pmmp.io/ci/BoxOfDevs/CommandShop/CommandShop)
[![Build Status](https://travis-ci.org/BoxOfDevs/CommandShop.svg?branch=master)](https://travis-ci.org/BoxOfDevs/CommandShop)

[Come chat with us on Discord!](https://discord.me/bod)

[<img src="https://discordapp.com/assets/fc0b01fe10a0b8c602fb0106d8189d9b.png" width="162" height= "55">](https://discord.me/bod)

Players have to pay items or money to use specific commands! A PocketMine plugin.

### Please read the [wiki](https://github.com/BoxOfDevs/CommandShop/wiki) if you want to know how this plugin works!

###### This plugin was made for and is only tested on PocketMine-MP, you may want to report issues you have when using another variant of it (a so called spoon), but if they don't occur on standard PocketMine-MP too, fixing them won't be at a high priority. Feel free to always make a Pull Request though.

## Download this plugin!
You may grab the plugin from [source](https://github.com/BoxOfDevs/CommandShop/archive/master.zip), or download the latest .phar from [Poggit](https://poggit.pmmp.io/ci/BoxOfDevs/CommandShop/CommandShop).<br>
**This plugin requires [EconomyAPI](https://github.com/onebone/EconomyS) by onebone to enable buying commands via money!**
<br>

By BoxOfDevs:

![BoxOfDevs Banner](http://files.himbeer.me/bod-banner.gif)

## License
This work is licensed under the BoxOfDevs General Software License 1.1.3
